export const API_URL = import.meta.env.VITE_API_URL;
export const PY_API_URL = import.meta.env.VITE_PY_API_URL;

export const API_URL_COMMUNITY = import.meta.env.VITE_API_COMMUNITY_URL;
export const API_URL_PROPERTY = import.meta.env.VITE_API_PROPERTY_URL;
export const API_URL_UNIT = import.meta.env.VITE_API_UNIT_URL;

// EmailJS
export const EMAIL_SERVICE_ID = import.meta.env.VITE_EMAIL_SERVICE_ID;
export const EMAIL_TEMPLATE_ID = import.meta.env.VITE_EMAIL_TEMPLATE_ID;
export const EMAIL_PUBLIC_KEY = import.meta.env.VITE_EMAIL_PUBLIC_KEY;