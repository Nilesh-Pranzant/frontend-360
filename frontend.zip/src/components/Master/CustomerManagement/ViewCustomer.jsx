import React from "react";
import { X } from "lucide-react";
import { useTheme } from "../../../ui/Settings/themeUtils";

const ViewCustomer = ({ customer, onClose }) => {
  const { themeUtils } = useTheme();

  // Early return if no data or wrong shape
  if (!customer || !customer.customer) return null;

  // Main customer object is nested
  const cust = customer.customer;
  const units = customer.units || [];
  const documents = customer.documents || [];

  const formatPhone = (phone) => {
    if (!phone) return "-";
    // UAE / +971 formatting
    if (phone.startsWith("+971") && phone.length === 13) {
      return `${phone.substring(0, 4)} ${phone.substring(4, 7)} ${phone.substring(7)}`;
    }
    if (phone.startsWith("971") && phone.length === 12) {
      return `+${phone.substring(0, 3)} ${phone.substring(3, 6)} ${phone.substring(6)}`;
    }
    return phone;
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return "-";
    try {
      return new Date(dateStr).toISOString().split("T")[0];
    } catch {
      return dateStr;
    }
  };

  return (
    <div
      className="flex flex-col h-full rounded-lg"
      style={{ backgroundColor: themeUtils.getBgColor("default") }}
    >
      <div
        className="flex-1 overflow-y-auto p-4 lg:p-6"
        style={{
          scrollbarWidth: "none",
          msOverflowStyle: "none",
        }}
      >
        <style jsx>{`
          div::-webkit-scrollbar {
            display: none;
          }
        `}</style>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left - Profile Image */}
          <div className="lg:col-span-1 flex flex-col items-center lg:items-start">
            <div
              className="w-full max-w-xs p-5 rounded-lg border"
              style={{
                backgroundColor: themeUtils.getBgColor("input"),
                borderColor: themeUtils.getBorderColor(),
              }}
            >
              <h3
                className="text-sm font-medium mb-4 text-center lg:text-left"
                style={{ color: themeUtils.getTextColor(true) }}
              >
                Profile Picture
              </h3>

              <img
                src={
                  cust.profile_picture ||
                  `https://ui-avatars.com/?name=${encodeURIComponent(
                    cust.full_name || "Customer"
                  )}&background=8b5cf6&color=fff&size=128`
                }
                alt={cust.full_name || "Customer"}
                className="w-full h-48 object-cover rounded-lg border"
                style={{ borderColor: themeUtils.getBorderColor() }}
              />
            </div>
          </div>

          {/* Right - All Details */}
          <div className="lg:col-span-2 space-y-10">
            {/* Personal Details */}
            <div>
              <h3
                className="text-lg font-bold mb-3"
                style={{ color: themeUtils.getTextColor(true) }}
              >
                Personal Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Full Name
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {cust.full_name || "-"}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Gender
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {cust.gender || "-"}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Email Address
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {cust.email || "-"}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Contact Number
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {formatPhone(cust.contact_number)}
                  </p>
                </div>
              </div>
            </div>

            <hr style={{ borderColor: themeUtils.getBorderColor() }} />

            {/* Address Details */}
            <div>
              <h3
                className="text-lg font-bold mb-3"
                style={{ color: themeUtils.getTextColor(true) }}
              >
                Address Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Country
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {cust.country || "-"}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    City
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {cust.city || "-"}
                  </p>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Address Line 1
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {cust.address_line1 || "-"}
                  </p>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Address Line 2
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {cust.address_line2 || "-"}
                  </p>
                </div>
              </div>
            </div>

            <hr style={{ borderColor: themeUtils.getBorderColor() }} />

            {/* Allocation / Property Details */}
            <div>
              <h3
                className="text-lg font-bold mb-3"
                style={{ color: themeUtils.getTextColor(true) }}
              >
                Allocation Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Community
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {cust.community_name || "-"}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Property
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {cust.property_name || "-"}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Unit(s)
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {units.length > 0 ? units.join(", ") : "-"}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: themeUtils.getTextColor(false) }}>
                    Joining Date
                  </label>
                  <p className="text-base" style={{ color: themeUtils.getTextColor(true) }}>
                    {formatDate(cust.joining_date)}
                  </p>
                </div>
              </div>
            </div>

            <hr style={{ borderColor: themeUtils.getBorderColor() }} />

            {/* Documents Section */}
            <div>
              <h3
                className="text-lg font-bold mb-3"
                style={{ color: themeUtils.getTextColor(true) }}
              >
                Documents
              </h3>

              {documents.length === 0 ? (
                <p className="text-sm italic" style={{ color: themeUtils.getTextColor(false) }}>
                  No documents uploaded
                </p>
              ) : (
                <div className="space-y-4">
                  {documents.map((doc, index) => (
                    <div
                      key={index}
                      className="p-3 rounded border"
                      style={{
                        borderColor: themeUtils.getBorderColor(),
                        backgroundColor: themeUtils.getBgColor("input"),
                      }}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium" style={{ color: themeUtils.getTextColor(true) }}>
                            {doc.description || "Unnamed document"}
                          </p>
                          {doc.unit_id && (
                            <p className="text-sm" style={{ color: themeUtils.getTextColor(false) }}>
                              Unit ID: {doc.unit_id}
                            </p>
                          )}
                        </div>
                        <a
                          href={doc.document_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm underline"
                          style={{ color: themeUtils.getTextColor(true) }}
                        >
                          View
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div
        className="p-4 border-t flex justify-end"
        style={{ borderColor: themeUtils.getBorderColor() }}
      >
        <button
          onClick={onClose}
          className="px-6 py-2 rounded-lg font-medium"
          style={{
            backgroundColor: themeUtils.getBgColor("secondary"),
            color: themeUtils.getTextColor(true),
          }}
        >
          Close
        </button>
      </div>
    </div>
  );
};

export default ViewCustomer;