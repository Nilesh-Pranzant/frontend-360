// pages/Dashboard/CustomerDashboard.jsx
import React, { useState } from "react";
import Card, { 
  CardHeader, 
  CardTitle, 
  CardContent, 
  StatsCard 
} from "../../../ui/Common/Card.jsx";

import { 
  Users, 
  FileText, 
  Home 
} from "lucide-react";

import { useTheme } from "../../../ui/Settings/themeUtils.jsx"; // ← added

const CustomerDashboard = () => {
  const [showModal, setShowModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const { themeUtils } = useTheme(); // ← use theme utils

  const primaryText = themeUtils.getTextColor(true);
  const secondaryText = themeUtils.getTextColor(false);

  // Mock data for stats
  const stats = [
    {
      icon: Home,
      iconBg: "#3B82F6",
      iconColor: "#FFFFFF",
      title: "Total Units",
      value: "1,234",
      subtitle: "Across all properties",
 
      trendLabel: "from last month"
    },
    {
      icon: Users,
      iconBg: "#10B981",
      iconColor: "#FFFFFF",
      title: "Total Customers",
      value: "856",
      subtitle: "Active accounts",
     
      trendLabel: "from last month"
    },
    {
      icon: FileText,
      iconBg: "#8B5CF6",
      iconColor: "#FFFFFF",
      title: "Total Documents",
      value: "2,450",
      subtitle: "Verified files",

      trendLabel: "from last month"
    }
  ];

  // Mock data for handover Details table
  const handoverData = [
    {
      id: 1,
      customerName: "Amit Sharma",
      unitNumber: "A-101",
      propertyName: "Sunrise Apartments",
      handoverDate: "2024-01-15",
      status: "Handed Over",
      documents: "Complete",
      documentsList: ["Aadhaar Card.pdf", "PAN Card.pdf", "Sale Agreement.pdf"]
    },
    {
      id: 2,
      customerName: "Priya Patel",
      unitNumber: "B-205",
      propertyName: "Green Valley Towers",
      handoverDate: "2024-02-20",
      status: "Pending",
      documents: "Partial"
    },
    {
      id: 3,
      customerName: "Rajesh Kumar",
      unitNumber: "C-312",
      propertyName: "Sunrise Apartments",
      handoverDate: "2024-03-10",
      status: "Handed Over",
      documents: "Complete",
      documentsList: ["Voter ID.pdf", "Bank Statement.pdf", "Handover Agreement.pdf"]
    },
    {
      id: 4,
      customerName: "Sneha Reddy",
      unitNumber: "D-108",
      propertyName: "Green Valley Towers",
      handoverDate: "2024-04-05",
      status: "In Progress",
      documents: "Pending"
    },
    {
      id: 5,
      customerName: "Vikram Singh",
      unitNumber: "A-415",
      propertyName: "Blue Horizon Residences",
      handoverDate: "2024-05-18",
      status: "Handed Over",
      documents: "Complete",
      documentsList: ["Passport.pdf", "Utility Bill.pdf", "Lease Document.pdf"]
    }
  ];

  const filteredData = handoverData.filter(row => 
    row.customerName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const openDocumentsModal = (customerName) => {
    setSelectedCustomer(customerName);
    setShowModal(true);
  };

  const docs = selectedCustomer ? 
    handoverData.find(row => row.customerName === selectedCustomer)?.documentsList || [] 
    : [];

  return (
    <div className="space-y-2">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1
            className="text-3xl font-bold"
            style={{ color: primaryText }}
          >
            Customer Dashboard
          </h1>

       
        </div>

        <div className="text-right">
         
        </div>
      </div>

      {/* Stats Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {stats.map((stat, index) => (
          <StatsCard
            key={index}
            {...stat}
            loading={false}
          />
        ))}
      </div>

      {/* handover Details Table */}
      <Card padding="p-0" className="overflow-hidden">
        <CardHeader className="p-4 border-b">
          <div className="flex justify-between items-center">
            <CardTitle style={{ color: primaryText }}>
              Handover Details
            </CardTitle>
            <input
              type="text"
              placeholder="Filter by customer name"
              className="px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>

        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y">
              <thead>
                <tr>
                  <th
                    className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider"
                    style={{ color: secondaryText }}
                  >
                    Customer Name
                  </th>
                  <th
                    className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider"
                    style={{ color: secondaryText }}
                  >
                    Unit Number
                  </th>
                  <th
                    className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider"
                    style={{ color: secondaryText }}
                  >
                    Property Name
                  </th>
                  <th
                    className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider"
                    style={{ color: secondaryText }}
                  >
                    Handover Date
                  </th>
                  <th
                    className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider"
                    style={{ color: secondaryText }}
                  >
                    Documents
                  </th>
                </tr>
              </thead>

              <tbody>
                {filteredData.map((row) => (
                  <tr key={row.id}>
                    <td
                      className="px-6 py-4 whitespace-nowrap text-sm font-medium"
                      style={{ color: primaryText }}
                    >
                      {row.customerName}
                    </td>
                    <td
                      className="px-6 py-4 whitespace-nowrap text-sm"
                      style={{ color: secondaryText }}
                    >
                      {row.unitNumber}
                    </td>
                    <td
                      className="px-6 py-4 whitespace-nowrap text-sm"
                      style={{ color: secondaryText }}
                    >
                      {row.propertyName}
                    </td>
                    <td
                      className="px-6 py-4 whitespace-nowrap text-sm"
                      style={{ color: secondaryText }}
                    >
                      {row.handoverDate}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      {row.documents === "Complete" ? (
                        <button
                          onClick={() => openDocumentsModal(row.customerName)}
                          className="text-green-800 font-semibold underline cursor-pointer hover:text-green-900"
                        >
                          {row.documents}
                        </button>
                      ) : row.documents === "Partial" ? (
                        <span className="text-yellow-800 font-semibold">Partial</span>
                      ) : (
                        <span className="text-red-800 font-semibold">Pending</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="px-6 py-3 border-t">
            <p
              className="text-sm"
              style={{ color: secondaryText }}
            >
              Showing {filteredData.length} of {handoverData.length} entries
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Documents Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <h2 className="text-xl font-bold mb-4 text-gray-900">
              Documents for {selectedCustomer}
            </h2>
            {docs.length > 0 ? (
              <ul className="list-disc pl-5 space-y-1 mb-4">
                {docs.map((doc, idx) => (
                  <li key={idx} className="text-sm text-gray-700">
                    {doc}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-500 mb-4">No documents available.</p>
            )}
            <button
              onClick={() => setShowModal(false)}
              className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600"
            >
              Close
            </button>
          </div>
        </div>
      )}

    </div>
  );
};

export default CustomerDashboard;