import React, { useState, useEffect, useRef } from "react";
import { Plus, Download, RefreshCw } from "lucide-react";
import { useTheme } from "../../../ui/Settings/themeUtils.jsx";
import { useToast } from "../../../ui/common/CostumeTost.jsx";
import SearchBar from "../../../ui/common/SearchBar";
import RecordsPerPage from "../../../ui/common/RecordsPerPage";
import Table from "../../../ui/common/Table.jsx";
import ThreeDotsMenu from "../../../ui/common/ThreeDotsMenu";
import CommonDialog from "../../../ui/common/CommonDialog";
import { CardHeader, CardTitle } from "../../../ui/common/Card.jsx";
import AddCustomer from "./AddCustomer.jsx";
import ViewCustomer from "./ViewCustomer";
import EditCustomer from "./EditCustomer";
import Pagination from "../../../ui/common/Pagination.jsx";
import CustomConfirmDialog from "../../../ui/common/CustomConfirmDialog.jsx";
import Button from "../../../ui/Common/Button.jsx";
// ────────────────────────────────────────────────
// API BASE URL — change this according to your environment
// ────────────────────────────────────────────────
const API_BASE = "http://192.168.1.8:5000/api"; // ← adjust this (or use env variable)

const ListCustomer = () => {
  const { themeUtils } = useTheme();
  const toast = useToast();
  const deleteInProgress = useRef(false);

  const [confirmDialogVisible, setConfirmDialogVisible] = useState(false);
  const [customerToDelete, setCustomerToDelete] = useState(null);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [perPage, setPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);
  const [isAddDrawerOpen, setIsAddDrawerOpen] = useState(false);
  const [isViewDrawerOpen, setIsViewDrawerOpen] = useState(false);
  const [isEditDrawerOpen, setIsEditDrawerOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [totalCount, setTotalCount] = useState(0);

  // Fetch customers when search or component mounts
  useEffect(() => {
    const fetchCustomers = async () => {
      setLoading(true);

      try {
        const url = `${API_BASE}/customers?search=${encodeURIComponent(search.trim())}`;

        const res = await fetch(url);
        const data = await res.json();

        console.log("Customer API Response:", data);

        if (!data.success) {
          throw new Error(data.message || "Failed to load customers");
        }

        const formatted = data.data.map((item) => {
          const c = item.customer || {};
          const units = item.units || [];

          return {
            customer_id: c.customer_id,
            customer_code: `C-${String(c.customer_id).padStart(4, "0")}`,

            full_name: c.full_name || "",
            gender: c.gender || "-",

            email: c.email || "",
            phone: c.contact_number || "",

            nationality: c.country || "",
            country: c.country || "",
            city: c.city || "",

            address_line1: c.address_line1 || "",
            address_line2: c.address_line2 || "",

            // Not returned by current function → will show "-" for now
            community: "-",
            property: "-",

            // Multiple units handling
            unit_number: units.length === 0 ? "-" :
                         units.length === 1 ? String(units[0]) :
                         `${units[0]} +${units.length - 1}`,

            status: c.is_active ? "Active" : "Inactive",

            join_date: c.joining_date
              ? new Date(c.joining_date).toISOString().split("T")[0]
              : "-",

            profile_picture: c.profile_picture
              ? `${API_BASE}${c.profile_picture}`
              : null,
          };
        });

        setCustomers(formatted);
      } catch (err) {
        console.error(err);
        toast.error("Error", "Failed to load customers");
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, [search]);

  // ─── Pagination Logic (client-side for now) ───────────────────────────────
  const filteredCustomers = customers;
  const paginatedCustomers =
    perPage === "All" || perPage === Infinity || perPage <= 0
      ? filteredCustomers
      : filteredCustomers.slice(
          (currentPage - 1) * perPage,
          currentPage * perPage
        );

  const totalPages =
    perPage === "All" || perPage === Infinity || perPage <= 0
      ? 1
      : Math.ceil(filteredCustomers.length / perPage);

  // ─── Actions ──────────────────────────────────────────────────────────────
  const handleDeleteClick = (customerId) => {
    if (deleteInProgress.current) return;
    setCustomerToDelete(customerId);
    setConfirmDialogVisible(true);
  };

  const handleDeleteConfirm = async () => {
    if (!customerToDelete) return;
    deleteInProgress.current = true;
    setConfirmDialogVisible(false);

    try {
      const res = await fetch(`${API_BASE}/customers/${customerToDelete}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
      });
      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.message || "Delete failed");
      }

      setCustomers((prev) => prev.filter((c) => c.customer_id !== customerToDelete));
      toast.success("Deleted!", "Customer deleted successfully.");
    } catch (err) {
      console.error(err);
      toast.error("Error", "Failed to delete customer");
    } finally {
      deleteInProgress.current = false;
      setCustomerToDelete(null);
    }
  };

  const handleDeleteReject = () => {
    setConfirmDialogVisible(false);
    setCustomerToDelete(null);
    deleteInProgress.current = false;
  };

  const handleView = (customer) => {
    setSelectedCustomer(customer);
    setIsViewDrawerOpen(true);
  };

  const handleEdit = (customer) => {
    setSelectedCustomer(customer);
    setIsEditDrawerOpen(true);
  };

  const handleAdd = () => setIsAddDrawerOpen(true);

  const handleAddSuccess = (newCustomerFromForm) => {
    setCustomers((prev) => [
      {
        ...newCustomerFromForm,
        customer_id: newCustomerFromForm.customer_id || `temp-${Date.now()}`,
        customer_code: newCustomerFromForm.customer_code || "New",
        gender: newCustomerFromForm.gender || "-",
        country: newCustomerFromForm.country || "",
        city: newCustomerFromForm.city || "",
        address_line1: newCustomerFromForm.address_line1 || "",
        address_line2: newCustomerFromForm.address_line2 || "",
        profile_picture: newCustomerFromForm.profile_picture
          ? `${API_BASE}${newCustomerFromForm.profile_picture}`
          : null,
      },
      ...prev,
    ]);
    setIsAddDrawerOpen(false);
    toast.success("Success", "Customer added successfully!");
    setSearch(search); // trigger refresh
  };

  const handleEditSuccess = () => {
    setIsEditDrawerOpen(false);
    toast.success("Success", "Customer updated successfully!");
    setSearch(search); // trigger refresh
  };

  // ─── Export CSV ───────────────────────────────────────────────────────────
  const exportCSV = () => {
    const headers = [
      "Sr. No",
      "Full Name",
      "Phone",
      "Community",
      "Property",
      "Unit Number",
      "Join Date",
    ];
    const csv = [
      headers.join(","),
      ...filteredCustomers.map((c, i) => [
        i + 1,
        `"${c.full_name?.replace(/"/g, '""') || ""}"`,
        `"${c.phone || ""}"`,
        `"${c.community?.replace(/"/g, '""') || ""}"`,
        `"${c.property?.replace(/"/g, '""') || ""}"`,
        `"${c.unit_number?.replace(/"/g, '""') || ""}"`,
        `"${c.join_date || ""}"`,
      ].join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `customers_${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
    toast.success("Export Successful", "Customers exported successfully!");
  };

  const handleRefresh = () => {
    setSearch("");
    toast.success("Refreshed", "Customer list refreshed.");
  };

  // Helpers
  const truncateText = (text, maxLength = 18) => {
    if (!text || typeof text !== "string") return text || "-";
    return text.length <= maxLength ? text : text.substring(0, maxLength) + "...";
  };

  const formatPhone = (phone) => {
    if (!phone) return "-";
    if (phone.startsWith("971") && phone.length === 12) {
      return `+${phone.substring(0,3)} ${phone.substring(3,6)} ${phone.substring(6)}`;
    }
    if (phone.startsWith("+971") && phone.length === 13) {
      return `${phone.substring(0,4)} ${phone.substring(4,7)} ${phone.substring(7)}`;
    }
    return phone;
  };

  // ─── TABLE COLUMNS ────────────────────────────────────────────────────────
  const tableHeaders = [
    "Sr. No",
    "Profile",
    "Full Name",
    "Phone",
    "Community",
    "Property",
    "Unit",
    "Join Date",
    "Action",
  ];

  const renderRow = (customer, index) => (
    <>
      <td className="px-4 py-1.5 text-sm text-center" style={{ color: themeUtils.getTextColor(false) }}>
        {perPage === "All" || perPage === Infinity || perPage <= 0
          ? index + 1
          : (currentPage - 1) * perPage + index + 1}
      </td>
      <td className="px-4 py-1.5 text-center">
        <div className="flex justify-center">
          <img
            src={
              customer.profile_picture ||
              `https://ui-avatars.com/api/?name=${encodeURIComponent(customer.full_name || "User")}&background=8b5cf6&color=fff&size=40&bold=true`
            }
            alt={customer.full_name}
            className="w-10 h-10 rounded-full object-cover border"
            style={{
              borderColor: "#8b5cf6",
              boxShadow: "0 2px 4px rgba(0,0,0,0.1)"
            }}
            onError={(e) => {
              e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(customer.full_name || "User")}&background=8b5cf6&color=fff&size=40&bold=true`;
            }}
          />
        </div>
      </td>
      <td className="px-4 py-1.5 text-sm text-left truncate max-w-[180px]" title={customer.full_name} style={{ color: themeUtils.getTextColor(false) }}>
        {truncateText(customer.full_name)}
      </td>
      <td className="px-4 py-1.5 text-sm text-left" title={customer.phone} style={{ color: themeUtils.getTextColor(false) }}>
        {formatPhone(customer.phone)}
      </td>
      <td className="px-4 py-1.5 text-sm text-left truncate max-w-[180px]" title={customer.community} style={{ color: themeUtils.getTextColor(false) }}>
        {truncateText(customer.community)}
      </td>
      <td className="px-4 py-1.5 text-sm text-left truncate max-w-[160px]" title={customer.property} style={{ color: themeUtils.getTextColor(false) }}>
        {truncateText(customer.property || "-")}
      </td>
      <td className="px-4 py-1.5 text-sm text-center" style={{ color: themeUtils.getTextColor(false) }}>
        {customer.unit_number || "-"}
      </td>
      <td className="px-4 py-1.5 text-sm text-center" style={{ color: themeUtils.getTextColor(false) }}>
        {customer.join_date || "-"}
      </td>
      <td className="px-4 py-1.5 text-center">
        <ThreeDotsMenu
          onView={() => handleView(customer)}
          onEdit={() => handleEdit(customer)}
          onDelete={() => handleDeleteClick(customer.customer_id)}
          viewTitle="View Customer"
          editTitle="Edit Customer"
          deleteTitle="Delete Customer"
          menuAlignment="right"
        />
      </td>
    </>
  );

  return (
    <div className="space-y-4">
      <CustomConfirmDialog
        visible={confirmDialogVisible}
        onHide={handleDeleteReject}
        header="Delete Confirmation"
        message="Are you sure you want to delete this customer? This action cannot be undone."
        accept={handleDeleteConfirm}
        reject={handleDeleteReject}
        acceptLabel="Yes, Delete"
        rejectLabel="Cancel"
      />

      {/* Header */}
      <CardHeader>
        <div className="flex flex-col xl:flex-row items-center justify-between gap-2 px-2 py-1.5">
          <div className="shrink-0">
            <CardTitle themeUtils={themeUtils}>Customer List</CardTitle>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-4 w-full xl:w-auto">
            <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
              <RecordsPerPage value={perPage} onChange={setPerPage} className="shrink-0" />
              <SearchBar
                placeholder="Search Customers..."
                value={search}
                onChange={setSearch}
                size="medium"
                className="w-full sm:w-64"
              />
            </div>
            <div className="flex flex-row items-center gap-3 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0 hide-scrollbar">
              <Button variant="primary" icon={Plus} onClick={handleAdd} className="whitespace-nowrap shrink-0">
                Add Customer
              </Button>
              <Button
                variant="secondary"
                icon={RefreshCw}
                onClick={handleRefresh}
                className="whitespace-nowrap shrink-0"
                loading={loading}
              >
                Refresh
              </Button>
              <Button variant="success" icon={Download} onClick={exportCSV} className="whitespace-nowrap shrink-0">
                Export
              </Button>
            </div>
          </div>
        </div>
      </CardHeader>

      {/* Table */}
      <div className="overflow-x-auto hide-scrollbar-mx-4">
        <div className="inline-block min-w-full align-middle">
          <Table
            headers={tableHeaders}
            data={paginatedCustomers}
            renderRow={renderRow}
            loading={loading}
            emptyMessage="No customers found. Click 'Add Customer' to create one."
          />
        </div>
      </div>

      {/* Pagination */}
      {paginatedCustomers.length > 0 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
          themeUtils={themeUtils}
        />
      )}

      {/* Drawers */}
      <CommonDialog
        header="Add New Customer"
        visible={isAddDrawerOpen}
        onHide={() => setIsAddDrawerOpen(false)}
        position="right"
        fullHeight={true}
        width="75vw"
      >
        <AddCustomer
          onClose={() => setIsAddDrawerOpen(false)}
          onSuccess={handleAddSuccess}
        />
      </CommonDialog>

      <CommonDialog
        header="Customer Details"
        visible={isViewDrawerOpen}
        onHide={() => setIsViewDrawerOpen(false)}
        position="right"
        fullHeight={true}
        width="75vw"
      >
        <ViewCustomer
          customer={selectedCustomer}
          onClose={() => setIsViewDrawerOpen(false)}
        />
      </CommonDialog>

      <CommonDialog
        header="Edit Customer"
        visible={isEditDrawerOpen}
        onHide={() => setIsEditDrawerOpen(false)}
        position="right"
        fullHeight={true}
        width="75vw"
      >
        <EditCustomer
          customer={selectedCustomer}
          onClose={() => setIsEditDrawerOpen(false)}
          onSuccess={handleEditSuccess}
        />
      </CommonDialog>
    </div>
  );
};

export default ListCustomer;