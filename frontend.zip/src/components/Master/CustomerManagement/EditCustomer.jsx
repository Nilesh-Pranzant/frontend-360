import React, { useState, useEffect } from "react";
import { Upload, X } from "lucide-react";
import { useTheme } from "../../../ui/Settings/themeUtils";
import { useToast } from "../../../ui/common/CostumeTost";
import Button from "../../../ui/common/Button.jsx";
import { useNavigate } from "react-router-dom";

// ────────────────────────────────────────────────
// API Configuration
// ────────────────────────────────────────────────
const API_BASE = "http://192.168.1.8:5000/api";   // ← adjust if needed

const EditCustomer = ({ customer, onClose, onSuccess }) => {
  const { themeUtils } = useTheme();
  const toast = useToast();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(true);

  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [existingImage, setExistingImage] = useState(null);

  const [communities, setCommunities] = useState([]);
  const [properties, setProperties] = useState([]);
  const [units, setUnits] = useState([]);

  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);

  const [form, setForm] = useState({
    full_name: "",
    gender: "",
    email: "",
    contact_number: "",
    country: "",
    city: "",
    address_line1: "",
    address_line2: "",
    community_id: "",
    property_id: "",
    unit_id: "",
    joining_date: "",
  });

  const [errors, setErrors] = useState({
    full_name: "",
    email: "",
    contact_number: "",
    address_line1: "",
    country: "",
  });

  // ─── Load initial customer data ───────────────────────────────
  useEffect(() => {
    if (!customer || !customer.customer_id) {
      toast.error("Error", "No customer selected for editing");
      onClose?.();
      setFetchLoading(false);
      return;
    }

    const loadCustomer = async () => {
      try {
        setFetchLoading(true);

        const res = await fetch(`${API_BASE}/customers/${customer.customer_id}`);
        if (!res.ok) {
          throw new Error(`Failed to load customer (HTTP ${res.status})`);
        }

        const json = await res.json();
        console.log("Single customer API response:", json);

        const cust = json.data?.customer || json.data || json;

        if (!cust || !cust.customer_id) {
          throw new Error("Customer data not found in response");
        }

        // Clean phone number (remove common prefixes)
        let contact = (cust.contact_number || "").trim();
        contact = contact.replace(/^\+971|^971|^0/, "");

        // Format date for input type="date"
        const formattedJoinDate = cust.joining_date
          ? new Date(cust.joining_date).toISOString().split("T")[0]
          : "";

        setForm({
          full_name: cust.full_name || "",
          gender: cust.gender || "",
          email: cust.email || "",
          contact_number: contact,
          country: cust.country || "",
          city: cust.city || "",
          address_line1: cust.address_line1 || "",
          address_line2: cust.address_line2 || "",
          community_id: cust.community_id ? String(cust.community_id) : "",
          property_id: cust.property_id ? String(cust.property_id) : "",
          unit_id: "", // Note: single unit only — adjust if you fetch from units array
          joining_date: formattedJoinDate,
        });

        // Profile picture
        if (cust.profile_picture) {
          const imgPath = cust.profile_picture.startsWith("http")
            ? cust.profile_picture
            : `${API_BASE.replace("/api", "")}${cust.profile_picture}`;
          setExistingImage(imgPath);
        }

      } catch (err) {
        console.error("Error loading customer:", err);
        toast.error("Error", err.message || "Failed to load customer data");
        onClose?.();
      } finally {
        setFetchLoading(false);
      }
    };

    loadCustomer();
  }, [customer?.customer_id, onClose, toast]);

  // ─── Fetch communities ───────────────────────────────
  useEffect(() => {
    const fetchCommunities = async () => {
      try {
        const res = await fetch(`${API_BASE}/communities`);
        if (!res.ok) throw new Error("Failed to load communities");
        const data = await res.json();
        setCommunities(data.data || data || []);
      } catch (err) {
        console.error(err);
        toast.error("Error", "Failed to load communities");
      }
    };
    fetchCommunities();
  }, []);

  // ─── Derive countries & cities ───────────────────────────────
  useEffect(() => {
    if (!communities.length) return;
    const uniqueCountries = [...new Set(communities.map(c => c.country).filter(Boolean))].sort();
    const uniqueCities = [...new Set(communities.map(c => c.city).filter(Boolean))].sort();
    setCountries(uniqueCountries);
    setCities(uniqueCities);
  }, [communities]);

  // ─── Properties when community changes ───────────────────────────────
  useEffect(() => {
    if (!form.community_id) {
      setProperties([]);
      setForm(prev => ({ ...prev, property_id: "", unit_id: "" }));
      return;
    }

    const fetchProperties = async () => {
      try {
        const res = await fetch(`${API_BASE}/properties?community_id=${form.community_id}`);
        if (!res.ok) throw new Error("Failed to load properties");
        const data = await res.json();
        const list = data.data || data || [];
        setProperties(list);

        // Reset if current property_id not in list
        if (!list.some(p => String(p.property_id) === form.property_id)) {
          setForm(prev => ({ ...prev, property_id: "", unit_id: "" }));
        }
      } catch (err) {
        console.error(err);
        toast.error("Error", "Failed to load properties");
      }
    };
    fetchProperties();
  }, [form.community_id]);

  // ─── Units when property changes ───────────────────────────────
  useEffect(() => {
    if (!form.property_id) {
      setUnits([]);
      setForm(prev => ({ ...prev, unit_id: "" }));
      return;
    }

    const fetchUnits = async () => {
      try {
        const res = await fetch(`${API_BASE}/units?property_id=${form.property_id}`);
        if (!res.ok) throw new Error("Failed to load units");
        const data = await res.json();
        const list = data.data || data || [];
        setUnits(list);

        if (!list.some(u => String(u.unit_id) === form.unit_id)) {
          setForm(prev => ({ ...prev, unit_id: "" }));
        }
      } catch (err) {
        console.error(err);
        toast.error("Error", "Failed to load units");
      }
    };
    fetchUnits();
  }, [form.property_id]);

  // ─── File handlers ───────────────────────────────
  const handleFileChange = (e) => {
    const selected = e.target.files?.[0];
    if (!selected) return;

    const valid = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
    if (!valid.includes(selected.type)) {
      toast.error("Invalid File", "JPG, PNG, WEBP only");
      return;
    }
    if (selected.size > 5 * 1024 * 1024) {
      toast.error("Too Large", "Max 5MB");
      return;
    }

    setFile(selected);
    const reader = new FileReader();
    reader.onloadend = () => setPreviewUrl(reader.result);
    reader.readAsDataURL(selected);
  };

  const handleRemoveImage = () => {
    setFile(null);
    setPreviewUrl(null);
    setExistingImage(null);
    const input = document.getElementById("customer-image");
    if (input) input.value = "";
  };

  // ─── Validation ───────────────────────────────
  const validateField = (name, value) => {
    switch (name) {
      case "full_name":
        if (!value?.trim()) return "Full name required";
        if (value.trim().length < 2) return "Min 2 chars";
        if (value.trim().length > 100) return "Max 100 chars";
        return "";
      case "email":
        if (!value?.trim()) return "Email required";
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return "Invalid email";
        return "";
      case "contact_number":
        if (!value?.trim()) return "Contact required";
        if (!/^\d{7,15}$/.test(value)) return "7–15 digits only";
        return "";
      case "address_line1":
        if (!value?.trim()) return "Address line 1 required";
        if (value.trim().length > 200) return "Max 200 chars";
        return "";
      case "country":
        if (!value?.trim()) return "Country required";
        return "";
      default:
        return "";
    }
  };

  const validateForm = () => {
    const newErrors = {};
    ["full_name", "email", "contact_number", "address_line1", "country"].forEach(field => {
      const err = validateField(field, form[field]);
      if (err) newErrors[field] = err;
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
    setErrors(prev => ({ ...prev, [field]: validateField(field, value) }));
  };

  // ─── Submit ───────────────────────────────
  const handleSubmit = async () => {
    if (!validateForm()) {
      toast.error("Validation Error", "Fix highlighted fields");
      return;
    }

    setLoading(true);

    try {
      const formData = new FormData();

      formData.append("full_name", form.full_name.trim());
      formData.append("gender", form.gender || "");
      formData.append("email", form.email.trim());

      let phone = form.contact_number.trim().replace(/\D/g, "");
      if (phone) {
        phone = phone.startsWith("971") ? `+${phone}` : `+971${phone}`;
      }
      formData.append("contact_number", phone);

      formData.append("country", form.country.trim());
      formData.append("city", form.city?.trim() || "");
      formData.append("address_line1", form.address_line1.trim());
      formData.append("address_line2", form.address_line2?.trim() || "");

      // Allocation (single in edit mode)
      formData.append("community_id", form.community_id || "");
      formData.append("property_id", form.property_id || "");
      formData.append("unit_id", form.unit_id || "");
      formData.append("joining_date", form.joining_date || "");

      if (file) {
        formData.append("profile_picture", file);
      }

      const res = await fetch(`${API_BASE}/customers/${customer.customer_id}`, {
        method: "PUT",
        body: formData,
      });

      if (!res.ok) {
        const errJson = await res.json();
        throw new Error(errJson.message || `Update failed (${res.status})`);
      }

      const json = await res.json();
      console.log("Update success:", json);

      toast.success("Success", "Customer updated");
      onSuccess?.();
      onClose?.();

    } catch (err) {
      console.error("Update error:", err);
      toast.error("Error", err.message || "Update failed");
    } finally {
      setLoading(false);
    }
  };

  if (fetchLoading) {
    return (
      <div className="flex flex-col h-full items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500 mx-auto"></div>
        <p className="mt-4 text-gray-600">Loading customer details...</p>
      </div>
    );
  }

  return (
    <div
      className="flex flex-col h-full rounded-lg"
      style={{ backgroundColor: themeUtils.getBgColor("default") }}
    >
      <div className="flex-1 p-4 lg:p-6 overflow-y-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Profile Picture */}
          <div className="lg:col-span-1">
            <div
              className="p-5 rounded-lg border"
              style={{
                backgroundColor: themeUtils.getBgColor("input"),
                borderColor: themeUtils.getBorderColor(),
              }}
            >
              <h3 className="text-sm font-medium mb-4" style={{ color: themeUtils.getTextColor(true) }}>
                Profile Picture
              </h3>

              {(previewUrl || existingImage) ? (
                <div className="relative">
                  <img
                    src={previewUrl || existingImage}
                    alt="Profile"
                    className="w-full h-48 object-cover rounded-lg"
                    onError={e => e.target.src = "https://via.placeholder.com/300?text=No+Image"}
                  />
                  <button
                    onClick={handleRemoveImage}
                    className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-full hover:bg-red-600"
                    type="button"
                  >
                    <X size={16} />
                  </button>
                </div>
              ) : (
                <div
                  className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-blue-500"
                  style={{ borderColor: themeUtils.getBorderColor() }}
                  onClick={() => document.getElementById("customer-image")?.click()}
                >
                  <Upload size={32} className="mx-auto mb-3 text-gray-400" />
                  <p className="text-sm font-medium mb-1">Click to upload</p>
                  <p className="text-xs text-gray-500">JPG, PNG, WEBP (max 5MB)</p>
                </div>
              )}

              <input
                id="customer-image"
                type="file"
                accept="image/jpeg,image/jpg,image/png,image/webp"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-2 space-y-8">
            {/* Personal Details */}
            <div>
              <h3 className="text-lg font-semibold mb-4" style={{ color: themeUtils.getTextColor(true) }}>
                Personal Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <div className="flex justify-between mb-1.5">
                    <label className="text-sm font-medium" style={{ color: themeUtils.getTextColor(false) }}>
                      Full Name *
                    </label>
                    <span className="text-xs text-gray-500">{form.full_name.length}/100</span>
                  </div>
                  <input
                    type="text"
                    value={form.full_name}
                    onChange={e => handleInputChange("full_name", e.target.value)}
                    maxLength={100}
                    className={`w-full px-4 py-2 text-sm rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500/30 ${
                      errors.full_name ? "border-red-500" : ""
                    }`}
                    style={{
                      backgroundColor: themeUtils.getBgColor("input"),
                      borderColor: errors.full_name ? "#ef4444" : themeUtils.getBorderColor(),
                      color: themeUtils.getTextColor(true),
                    }}
                    placeholder="Enter full name"
                  />
                  {errors.full_name && <p className="mt-1 text-xs text-red-500">⚠ {errors.full_name}</p>}
                </div>

                {/* Gender, Email, Contact, ... same as before but with minor cleanup */}

                {/* ... rest of personal fields same ... */}

              </div>
            </div>

            {/* Address, Allocation sections remain mostly unchanged */}

            {/* ... keep your existing address & allocation JSX ... */}

          </div>
        </div>
      </div>

      {/* Footer same as before */}
      <div
        className="flex flex-col sm:flex-row justify-between items-center gap-4 p-5 border-t"
        style={{ borderColor: themeUtils.getBorderColor() }}
      >
        <div className="text-sm" style={{ color: themeUtils.getTextColor(false, true) }}>
          * Required fields
          {Object.values(errors).some(e => e) && (
            <span className="ml-3 text-red-500">
              Fix {Object.values(errors).filter(Boolean).length} error(s)
            </span>
          )}
        </div>

        <div className="flex gap-3">
          <Button variant="secondary" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={handleSubmit}
            loading={loading}
            disabled={loading || Object.values(errors).some(e => e)}
          >
            {loading ? "Saving..." : "Update Customer"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default EditCustomer;